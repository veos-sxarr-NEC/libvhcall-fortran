var interfacevhcall__fortran__lowlevel_1_1vhcall__invoke__with__args =
[
    [ "vhcall_invoke_with_args", "interfacevhcall__fortran__lowlevel_1_1vhcall__invoke__with__args.html#a24dd6fae7781f22325eb47e0d95e6258", null ]
];